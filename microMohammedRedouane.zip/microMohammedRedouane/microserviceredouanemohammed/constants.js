exports.DATA = 'data';
exports.ERROR = 'error';
exports.END = 'end';
